import { openDatabase, promisify, txDone } from './db.js';
import { STORES, DB_VERSION } from './schema.js';

const ALL_STORES = Object.values(STORES);

/** Dumps every store to a plain object (manual backup for offline devices). */
export async function exportAll() {
  const db = await openDatabase();
  const tx = db.transaction(ALL_STORES);
  const data = {};
  for (const name of ALL_STORES) {
    data[name] = await promisify(tx.objectStore(name).getAll());
  }
  return { app: 'farm-offline', version: DB_VERSION, exportedAt: new Date().toISOString(), data };
}

/** Restores a backup, replacing existing data in a single transaction. */
export async function importAll(backup) {
  if (backup?.app !== 'farm-offline' || !backup.data) {
    throw new Error('This file is not a valid Farm Offline backup.');
  }
  const db = await openDatabase();
  const tx = db.transaction(ALL_STORES, 'readwrite');
  for (const name of ALL_STORES) {
    const store = tx.objectStore(name);
    store.clear();
    for (const record of backup.data[name] ?? []) store.put(record);
  }
  await txDone(tx);
}

export function downloadBackup(backup) {
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `farm-backup-${backup.exportedAt.slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
}
