# Farm Offline

Offline-first farm management app. Data lives in the browser's IndexedDB.

## Run
IndexedDB and ES modules need a local server (not file://):

    python3 -m http.server 8000

Open http://localhost:8000

## Structure
    index.html
    manifest.webmanifest      PWA manifest (icons + service worker come in a later step)
    css/styles.css
    js/app.js                 entry point
    js/db/schema.js           stores, indexes, versioned migrations
    js/db/db.js               open/connect helpers
    js/db/repository.js       generic CRUD + ready-made repos + settings
    js/db/backup.js           export/import JSON backup
    js/db/index.js            single import point

## Changing the schema
Bump DB_VERSION in schema.js and add a new function to MIGRATIONS. Never edit an old one.
