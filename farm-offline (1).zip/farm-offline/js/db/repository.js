import { openDatabase, promisify, txDone } from './db.js';
import { STORES } from './schema.js';

const newId = () =>
  crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

/**
 * Generic CRUD wrapper around one object store.
 * Records get id, createdAt and updatedAt automatically.
 */
export class Repository {
  constructor(storeName) {
    this.storeName = storeName;
  }

  async #store(mode = 'readonly') {
    const db = await openDatabase();
    const tx = db.transaction(this.storeName, mode);
    return { tx, store: tx.objectStore(this.storeName) };
  }

  async add(data) {
    const now = new Date().toISOString();
    const record = { ...data, id: data.id ?? newId(), createdAt: now, updatedAt: now };
    const { tx, store } = await this.#store('readwrite');
    store.add(record);
    await txDone(tx);
    return record;
  }

  /** Merges changes into an existing record. */
  async update(id, changes) {
    const { tx, store } = await this.#store('readwrite');
    const existing = await promisify(store.get(id));
    if (!existing) {
      tx.abort();
      throw new Error(`${this.storeName}: record ${id} not found`);
    }
    const record = { ...existing, ...changes, id, updatedAt: new Date().toISOString() };
    store.put(record);
    await txDone(tx);
    return record;
  }

  async get(id) {
    const { store } = await this.#store();
    return promisify(store.get(id));
  }

  async getAll() {
    const { store } = await this.#store();
    return promisify(store.getAll());
  }

  /** e.g. repo.getByIndex('fieldId', someId) */
  async getByIndex(indexName, value) {
    const { store } = await this.#store();
    return promisify(store.index(indexName).getAll(value));
  }

  /** Inclusive range on an index, e.g. repo.getRange('date', '2026-01-01', '2026-03-31') */
  async getRange(indexName, lower, upper) {
    const { store } = await this.#store();
    return promisify(store.index(indexName).getAll(IDBKeyRange.bound(lower, upper)));
  }

  async remove(id) {
    const { tx, store } = await this.#store('readwrite');
    store.delete(id);
    await txDone(tx);
  }

  async count() {
    const { store } = await this.#store();
    return promisify(store.count());
  }

  async clear() {
    const { tx, store } = await this.#store('readwrite');
    store.clear();
    await txDone(tx);
  }
}

/** Ready-to-use repositories. */
export const fieldsRepo = new Repository(STORES.FIELDS);
export const cropsRepo = new Repository(STORES.CROPS);
export const activitiesRepo = new Repository(STORES.ACTIVITIES);
export const harvestsRepo = new Repository(STORES.HARVESTS);
export const inventoryRepo = new Repository(STORES.INVENTORY);
export const expensesRepo = new Repository(STORES.EXPENSES);

/** Simple key/value settings (currency, units, ...). */
export const settings = {
  async get(key, fallback = null) {
    const db = await openDatabase();
    const row = await promisify(db.transaction(STORES.SETTINGS).objectStore(STORES.SETTINGS).get(key));
    return row ? row.value : fallback;
  },
  async set(key, value) {
    const db = await openDatabase();
    const tx = db.transaction(STORES.SETTINGS, 'readwrite');
    tx.objectStore(STORES.SETTINGS).put({ key, value });
    await txDone(tx);
  },
};
