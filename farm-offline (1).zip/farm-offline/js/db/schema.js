/**
 * Database schema definition.
 * Bump DB_VERSION and add a new entry to MIGRATIONS whenever the schema changes.
 * Never edit an old migration after it has shipped: users' devices have already run it.
 */
export const DB_NAME = 'farm-offline';
export const DB_VERSION = 1;

/** Store names, so the rest of the app never uses raw strings. */
export const STORES = Object.freeze({
  FIELDS: 'fields',         // plots / parcels of land
  CROPS: 'crops',           // a crop planted in a field for a season
  ACTIVITIES: 'activities', // sowing, irrigation, spraying, weeding, etc.
  HARVESTS: 'harvests',     // yield records per crop
  INVENTORY: 'inventory',   // seeds, fertilizer, pesticide, tools
  EXPENSES: 'expenses',     // costs and income
  SETTINGS: 'settings',     // key/value app settings
});

/**
 * Each migration receives the live database and the upgrade transaction.
 * Migrations run in order, only for versions newer than the user's current one.
 */
const MIGRATIONS = {
  1(db) {
    const fields = db.createObjectStore(STORES.FIELDS, { keyPath: 'id' });
    fields.createIndex('name', 'name');

    const crops = db.createObjectStore(STORES.CROPS, { keyPath: 'id' });
    crops.createIndex('fieldId', 'fieldId');
    crops.createIndex('status', 'status');          // planned | growing | harvested
    crops.createIndex('season', 'season');

    const activities = db.createObjectStore(STORES.ACTIVITIES, { keyPath: 'id' });
    activities.createIndex('cropId', 'cropId');
    activities.createIndex('fieldId', 'fieldId');
    activities.createIndex('date', 'date');
    activities.createIndex('type', 'type');

    const harvests = db.createObjectStore(STORES.HARVESTS, { keyPath: 'id' });
    harvests.createIndex('cropId', 'cropId');
    harvests.createIndex('date', 'date');

    const inventory = db.createObjectStore(STORES.INVENTORY, { keyPath: 'id' });
    inventory.createIndex('category', 'category');
    inventory.createIndex('name', 'name');

    const expenses = db.createObjectStore(STORES.EXPENSES, { keyPath: 'id' });
    expenses.createIndex('date', 'date');
    expenses.createIndex('type', 'type');           // expense | income
    expenses.createIndex('category', 'category');
    expenses.createIndex('cropId', 'cropId');

    db.createObjectStore(STORES.SETTINGS, { keyPath: 'key' });
  },

  // 2(db, tx) { ... future changes go here ... }
};

/** Runs every migration between oldVersion and newVersion. */
export function runMigrations(db, tx, oldVersion, newVersion) {
  for (let v = oldVersion + 1; v <= newVersion; v++) {
    const migrate = MIGRATIONS[v];
    if (!migrate) throw new Error(`Missing migration for version ${v}`);
    migrate(db, tx);
  }
}
