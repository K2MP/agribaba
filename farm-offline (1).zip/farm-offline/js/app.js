import { openDatabase, requestPersistentStorage, fieldsRepo, settings, DB_NAME, DB_VERSION } from './db/index.js';

const statusEl = document.getElementById('db-status');

async function init() {
  try {
    await openDatabase();
    const persisted = await requestPersistentStorage();

    // First-run defaults
    if ((await settings.get('currency')) === null) {
      await settings.set('currency', 'INR');
      await settings.set('areaUnit', 'acre');
    }

    const fieldCount = await fieldsRepo.count();
    statusEl.textContent =
      `Database "${DB_NAME}" v${DB_VERSION} ready. ${fieldCount} field(s) saved. ` +
      `Persistent storage: ${persisted ? 'granted' : 'not granted'}.`;
    statusEl.dataset.state = 'ok';
  } catch (err) {
    console.error(err);
    statusEl.textContent = `Database could not start: ${err.message}`;
    statusEl.dataset.state = 'error';
  }
}

init();
