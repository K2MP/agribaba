import { DB_NAME, DB_VERSION, runMigrations } from './schema.js';

let dbPromise = null;

/** Opens the database once and reuses the connection. */
export function openDatabase() {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('IndexedDB is not supported in this browser.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      try {
        runMigrations(request.result, request.transaction, event.oldVersion, event.newVersion);
      } catch (err) {
        request.transaction.abort();
        reject(err);
      }
    };

    request.onsuccess = () => {
      const db = request.result;
      // Another tab upgraded the schema: close so it isn't blocked.
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };

    request.onerror = () => {
      dbPromise = null;
      reject(request.error);
    };

    // Another tab still has an older version open.
    request.onblocked = () => {
      console.warn('Database upgrade blocked: close other tabs of this app.');
    };
  });

  return dbPromise;
}

/** Wraps an IDBRequest in a Promise. */
export function promisify(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/** Resolves when a transaction commits. */
export function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
  });
}

/** Asks the browser not to evict our data when storage is low. */
export async function requestPersistentStorage() {
  if (navigator.storage?.persist) {
    return navigator.storage.persist();
  }
  return false;
}
